def my_function(x):
    return x + 1
